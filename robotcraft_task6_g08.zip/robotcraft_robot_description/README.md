# robotcraft_robot_description
Package to launch the RC Robot Model (urdf) in rviz